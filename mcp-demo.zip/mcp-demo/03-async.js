// ============================================================
// JS 基础 03：异步编程（Promise + async/await）
// 运行：node 03-async.js
// ============================================================

// ---------- ① 同步 vs 异步 ----------
console.log("① 同步代码开始");
console.log("这是同步的，立即执行");
console.log("① 同步代码结束\n");

// ---------- ② setTimeout（最基础的异步） ----------
console.log("② setTimeout 开始");
setTimeout(() => {
  console.log("  → 3 秒后执行（异步回调）");
}, 3000);
console.log("② setTimeout 结束（不用等 3 秒）\n");

// ---------- ③ Promise 基础 ----------
console.log("③ Promise 开始");

// 创建一个 Promise
const promise = new Promise((resolve, reject) => {
  console.log("  → Promise 内部立即执行");
  setTimeout(() => {
    const success = true;
    if (success) {
      resolve("成功！");  // Promise 解决（ fulfilled）
    } else {
      reject("失败！");   // Promise 拒绝（rejected）
    }
  }, 2000);
});

// 使用 Promise
promise
  .then(result => console.log(`  → then: ${result}`))
  .catch(error => console.log(`  → catch: ${error}`))
  .finally(() => console.log("  → finally: 无论成功失败都执行"));

console.log("③ Promise 结束（不用等 2 秒）\n");

// ---------- ④ async/await（更优雅的异步） ----------
console.log("④ async/await 开始");

// 模拟一个异步操作（如网络请求）
function fetchData(delay) {
  return new Promise(resolve => {
    setTimeout(() => {
      resolve(`数据（${delay}ms 后返回）`);
    }, delay);
  });
}

// async 函数：返回 Promise
// await：暂停等待 Promise 解决
async function demo() {
  console.log("  → 开始获取数据...");
  
  const data1 = await fetchData(1000);
  console.log(`  → 拿到 data1: ${data1}`);
  
  const data2 = await fetchData(1500);
  console.log(`  → 拿到 data2: ${data2}`);
  
  console.log("  → 全部完成！");
  return "done";
}

// 调用 async 函数
demo().then(result => {
  console.log(`④ async/await 结束: ${result}\n`);
  
  // ---------- ⑤ 错误处理 ----------
  console.log("⑤ 错误处理开始");
  
  function fetchWithError(shouldFail) {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        if (shouldFail) {
          reject(new Error("请求失败！"));
        } else {
          resolve("成功");
        }
      }, 1000);
    });
  }
  
  async function demoError() {
    try {
      const result = await fetchWithError(true);
      console.log(`  → 结果: ${result}`);
    } catch (error) {
      console.log(`  → 捕获错误: ${error.message}`);
    } finally {
      console.log("  → finally: 清理资源");
    }
  }
  
  demoError().then(() => {
    console.log("⑤ 错误处理结束\n");
    console.log("✅ 异步编程是 JS 的核心，server.js 里到处都是 await！");
  });
});
