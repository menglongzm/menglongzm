// ============================================================
// JS 基础 01：变量与基本类型
// 运行：node 01-variables.js
// ============================================================

// ---------- ① 变量声明（let 和 const） ----------
let name = "小明";        // 可变变量
const age = 18;           // 常量（不可重新赋值）
console.log(`姓名: ${name}, 年龄: ${age}`);

name = "小红";            // let 可以重新赋值
// age = 20;              // ❌ const 不能重新赋值（会报错）
console.log(`新姓名: ${name}`);

// ---------- ② 基本数据类型 ----------
const str = "hello";      // 字符串（string）
const num = 42;           // 数字（number）
const bool = true;        // 布尔值（boolean）
const nothing = null;     // 空值（null）
let undef;                // 未定义（undefined）

console.log("类型检测:");
console.log(typeof str);      // "string"
console.log(typeof num);      // "number"
console.log(typeof bool);     // "boolean"
console.log(typeof nothing);  // "object"（历史遗留 bug）
console.log(typeof undef);    // "undefined"

// ---------- ③ 字符串模板（反引号） ----------
const city = "北京";
const greeting = `你好，我是${name}，来自${city}`;
console.log(greeting);

// ---------- ④ 条件判断 ----------
const score = 85;
if (score >= 90) {
  console.log("优秀");
} else if (score >= 60) {
  console.log("及格");
} else {
  console.log("不及格");
}

// ---------- ⑤ 循环 ----------
console.log("for 循环:");
for (let i = 1; i <= 3; i++) {
  console.log(`第 ${i} 次`);
}

console.log("while 循环:");
let count = 0;
while (count < 3) {
  console.log(`count = ${count}`);
  count++;
}

console.log("\n✅ 运行完毕，试试修改上面的值看看效果！");
