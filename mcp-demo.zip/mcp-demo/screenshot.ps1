# ============================================================
# Windows 原生全屏截图脚本（主屏幕）
# 用法: powershell -NoProfile -ExecutionPolicy Bypass -File screenshot.ps1 <输出路径.png>
# 零依赖：仅用 .NET Framework 内置的 System.Drawing / System.Windows.Forms
# ============================================================
param([string]$OutputPath)

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

# 主屏幕边界（含任务栏区域；如需排除 DPI 缩放影响可另做处理，先保持最简单）
$bounds = [System.Windows.Forms.Screen]::PrimaryScreen.Bounds

$bitmap = New-Object System.Drawing.Bitmap $bounds.Width, $bounds.Height
$graphics = [System.Drawing.Graphics]::FromImage($bitmap)

# 从屏幕复制像素
$graphics.CopyFromScreen($bounds.Location, [System.Drawing.Point]::Empty, $bounds.Size)

$bitmap.Save($OutputPath, [System.Drawing.Imaging.ImageFormat]::Png)

$graphics.Dispose()
$bitmap.Dispose()

Write-Output "OK $($bounds.Width)x$($bounds.Height) -> $OutputPath"
