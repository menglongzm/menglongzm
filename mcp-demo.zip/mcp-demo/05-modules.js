// ============================================================
// JS 基础 05：模块系统（import/export）
// 运行：node 05-modules.js
// 注意：package.json 里要有 "type": "module" 才能用 import
// ============================================================

// ---------- ① 导出（export） ----------
// 方式 1：命名导出（可以导出多个）
export function add(a, b) {
  return a + b;
}

export function multiply(a, b) {
  return a * b;
}

// 方式 2：默认导出（只能导出一个）
export default class Calculator {
  constructor(name) {
    this.name = name;
  }
  
  calculate(a, b, operation) {
    switch (operation) {
      case "+": return add(a, b);
      case "*": return multiply(a, b);
      default: throw new Error("未知操作");
    }
  }
}

// ---------- ② 导入（import） ----------
// 注意：同一个文件里不能既导出又导入，这里演示语法

// 导入命名导出
// import { add, multiply } from "./05-modules.js";

// 导入默认导出（可以随便起名）
// import Calculator from "./05-modules.js";

// 导入全部（命名空间）
// import * as MathUtils from "./05-modules.js";

// ---------- ③ 实际使用示例（注释掉，避免循环依赖） ----------
/*
// 假设在另一个文件里：
import Calculator, { add, multiply } from "./05-modules.js";

console.log(add(2, 3));           // 5
console.log(multiply(4, 5));      // 20

const calc = new Calculator("科学计算器");
console.log(calc.calculate(10, 5, "+"));  // 15
console.log(calc.calculate(10, 5, "*"));  // 50
*/

// ---------- ④ server.js 里的实际例子 ----------
// server.js 第 6-11 行：
/*
import { Server } from "@modelcontextprotocol/sdk/server/index.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import {
  ListToolsRequestSchema,
  CallToolRequestSchema,
} from "@modelcontextprotocol/sdk/types.js";
*/

// 解释：
// - from "包名"：从 node_modules 导入
// - from "./文件路径"：从本地文件导入
// - { 名字 }：解构导入（只导入指定的）
// - 没有 {}：导入默认导出

// ---------- ⑤ 运行这个文件 ----------
console.log("✅ 这个文件演示了模块系统的语法");
console.log("   实际导入导出需要跨文件，这里只展示语法");
console.log("\n关键要点：");
console.log("1. export：导出（让别人用）");
console.log("2. import：导入（用别人的）");
console.log("3. 命名导出：export function xxx");
console.log("4. 默认导出：export default class xxx");
console.log("5. package.json 里要有 \"type\": \"module\"");
