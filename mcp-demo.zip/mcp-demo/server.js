// ============================================================
// 最小 MCP 服务器 demo（server 端）
// 对应四层架构：传输层(StdioServerTransport) + 协议层(SDK Server)
//             + 工具层(下面两个工具) + 生命周期(管道关闭即退出)
// ============================================================
import { Server } from "@modelcontextprotocol/sdk/server/index.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import {
  ListToolsRequestSchema,
  CallToolRequestSchema,
} from "@modelcontextprotocol/sdk/types.js";
import { execFile } from "node:child_process";
import { promisify } from "node:util";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { readFile, rm } from "node:fs/promises";
import { fileURLToPath } from "node:url";

const execFileAsync = promisify(execFile);
// 项目目录（用于定位 screenshot.ps1）
const PROJECT_DIR = fileURLToPath(new URL(".", import.meta.url));

// ---------- ① 创建 Server 实例（协议层：能力声明） ----------
const server = new Server(
  { name: "mcp-demo", version: "1.0.0" },
  { capabilities: { tools: {} } } // 声明支持 tools 能力（握手时告知客户端）
);

// ---------- ② 工具元数据（客户端 tools/list 时返回这份说明书） ----------
const TOOLS = [
  {
    name: "get_time",
    description: "返回当前系统时间（无参数）",
    inputSchema: { type: "object", properties: {}, required: [] },
  },
  {
    name: "echo",
    description: "原样返回传入的文本，可加前缀。用于演示带参工具的调用与校验",
    inputSchema: {
      type: "object",
      properties: {
        message: { type: "string", description: "要回显的文本" },
        prefix: { type: "string", description: "可选前缀，如 [INFO]" },
      },
      required: ["message"], // message 必填，prefix 可选
    },
  },
  {
    name: "take_screenshot",
    description:
      "截取当前屏幕全屏并返回 PNG 图片（协议 image 类型）；若传 filePath 则保存到该路径并返回路径文本",
    inputSchema: {
      type: "object",
      properties: {
        filePath: {
          type: "string",
          description: "可选：保存图片的完整路径（含 .png），不传则直接返回图片",
        },
      },
      required: [],
    },
  },
];

// ---------- ③ 工具层：功能函数 ----------
function getTime() {
  return new Date().toLocaleString("zh-CN");
}

function echo({ message, prefix }) {
  return prefix ? `${prefix} ${message}` : message;
}

// 全屏截图：调 Windows 原生 PowerShell 脚本（screenshot.ps1），零第三方依赖
// 返回两种形态：{ kind: "path" } 已落盘；{ kind: "image" } base64 数据
async function captureScreenshot(filePath) {
  const outPath = filePath ?? join(tmpdir(), `mcp-demo-${Date.now()}.png`);
  await execFileAsync(
    "powershell.exe",
    ["-NoProfile", "-ExecutionPolicy", "Bypass", "-File", join(PROJECT_DIR, "screenshot.ps1"), outPath],
    { timeout: 15000 } // 截图偶发慢，给 15s 上限，避免客户端永久等待
  );
  const data = await readFile(outPath);
  if (filePath) {
    return { kind: "path", text: `截图已保存: ${outPath} (${data.length} bytes)` };
  }
  await rm(outPath, { force: true }); // 临时文件用完即删
  return { kind: "image", data: data.toString("base64"), mimeType: "image/png" };
}

// ---------- ④ 协议层：注册 handler ----------

// tools/list：把说明书返回给客户端（客户端再注入模型上下文）
server.setRequestHandler(ListToolsRequestSchema, async () => ({
  tools: TOOLS,
}));

// tools/call：按 name 分发到功能函数，返回标准结果信封
server.setRequestHandler(CallToolRequestSchema, async (request) => {
  const { name, arguments: args } = request.params;

  let text;
  switch (name) {
    case "get_time":
      text = getTime();
      break;
    case "echo": {
      // 注意：SDK 只校验请求结构，不校验 inputSchema 的 required！
      // 缺参时 handler 自己返回 undefined 会让结果信封校验失败（-32602）
      // 正确做法：显式校验，并返回 isError 标记让模型知道这是业务错误
      if (typeof args?.message !== "string") {
        return {
          content: [{ type: "text", text: "缺少必填参数 message（string）" }],
          isError: true, // 协议标准：业务失败标记，模型可读文本作为错误原因
        };
      }
      text = echo(args);
      break;
    }
    case "take_screenshot": {
      const shot = await captureScreenshot(args?.filePath);
      if (shot.kind === "path") {
        text = shot.text;
      } else {
        // 协议 image 类型：base64 数据直接塞进结果信封
        return { content: [{ type: "image", data: shot.data, mimeType: shot.mimeType }] };
      }
      break;
    }
    default:
      // 未注册的工具：按协议返回错误
      throw new Error(`Unknown tool: ${name}`);
  }

  // 标准结果信封：content 数组，type: text
  return { content: [{ type: "text", text }] };
});

// ---------- ⑤ 生命周期：接上 stdio 管道，开始监听 ----------
const transport = new StdioServerTransport();
await server.connect(transport);
// 之后：客户端写入 stdin 的每一行 JSON 会被 SDK 解析并按方法分发；
// 客户端关闭 stdin 时进程退出。
