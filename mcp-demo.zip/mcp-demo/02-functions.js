// ============================================================
// JS 基础 02：函数与箭头函数
// 运行：node 02-functions.js
// ============================================================

// ---------- ① 传统函数声明 ----------
function greet(name) {
  return `你好，${name}！`;
}
console.log(greet("小明"));

// ---------- ② 箭头函数（ES6+） ----------
// 语法：(参数) => { 函数体 }
const greetArrow = (name) => {
  return `你好，${name}！`;
};
console.log(greetArrow("小红"));

// 简写 1：单行函数体（省略 return 和花括号）
const greetShort = (name) => `你好，${name}！`;
console.log(greetShort("小刚"));

// 简写 2：单参数（省略括号）
const double = x => x * 2;
console.log(`double(5) = ${double(5)}`);

// ---------- ③ 默认参数 ----------
function greetDefault(name = "访客") {
  return `你好，${name}！`;
}
console.log(greetDefault());        // 使用默认值
console.log(greetDefault("小明"));  // 使用传入值

// ---------- ④ 解构参数（对象） ----------
// server.js 里常见这种写法
const echo = ({ message, prefix }) => {
  return prefix ? `${prefix} ${message}` : message;
};
console.log(echo({ message: "Hello", prefix: "[INFO]" }));
console.log(echo({ message: "World" }));  // 没有 prefix

// ---------- ⑤ 回调函数（函数作为参数） ----------
function doSomething(callback) {
  console.log("开始执行...");
  callback();
}
doSomething(() => console.log("回调执行了！"));

// ---------- ⑥ 高阶函数（数组方法） ----------
const numbers = [1, 2, 3, 4, 5];

// map：映射（每个元素变换）
const doubled = numbers.map(n => n * 2);
console.log("map:", doubled);  // [2, 4, 6, 8, 10]

// filter：过滤
const evens = numbers.filter(n => n % 2 === 0);
console.log("filter:", evens);  // [2, 4]

// reduce：累积
const sum = numbers.reduce((acc, n) => acc + n, 0);
console.log("reduce:", sum);  // 15

// forEach：遍历（无返回值）
console.log("forEach:");
numbers.forEach(n => console.log(`  - ${n}`));

console.log("\n✅ 箭头函数是 JS 最常用的语法，多练！");
