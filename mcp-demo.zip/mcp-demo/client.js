// ============================================================
// 最小 MCP 客户端 demo（手写 JSON-RPC，不用 SDK Client）
// 作用：像真实 agent 框架一样与 server 对话，但把每条
//       "发出 -> 收到" 的消息原样打印出来，展示协议细节。
// ============================================================
import { spawn } from "node:child_process";
import { createInterface } from "node:readline";
import { fileURLToPath } from "node:url";
import { join } from "node:path";
import { writeFile } from "node:fs/promises";

const PROJECT_DIR = fileURLToPath(new URL(".", import.meta.url));

// ---------- 传输层：spawn 服务器子进程，建立 stdio 管道 ----------
// process.execPath 是当前 node 的完整路径；fileURLToPath 处理 Windows 盘符路径
const child = spawn(process.execPath, ["server.js"], {
  cwd: fileURLToPath(new URL(".", import.meta.url)), // 保证在项目目录内执行
  stdio: ["pipe", "pipe", "inherit"],
});

const rl = createInterface({ input: child.stdout });
let nextId = 1;

// 打印时把大字段（如截图 base64）截断，避免刷屏
function summarize(msg) {
  const m = JSON.parse(JSON.stringify(msg));
  if (m.result?.content) {
    for (const c of m.result.content) {
      if (c.type === "image" && c.data?.length > 60) {
        c.data = c.data.slice(0, 60) + `...(base64 共 ${m.result.content[0].data.length} 字符)`;
      }
    }
  }
  return m;
}

// 收消息：打印 + 按 id 唤起等待方
const pending = new Map();
rl.on("line", (line) => {
  const msg = JSON.parse(line);
  console.log(`\n[收] ${JSON.stringify(summarize(msg), null, 2)}`);
  if (msg.id !== undefined && pending.has(msg.id)) {
    pending.get(msg.id)(msg);
    pending.delete(msg.id);
  }
});

// 发消息：打印 + 写入子进程 stdin
function send(method, params, needReply = true) {
  const msg = { jsonrpc: "2.0", id: needReply ? nextId++ : undefined };
  if (needReply) msg.method = method;
  else {
    // 通知格式：没有 id，method 放在外层
    msg.method = method;
    delete msg.id;
  }
  if (params !== undefined) msg.params = params;
  if (msg.id === undefined) delete msg.id;
  console.log(`\n[发] ${JSON.stringify(msg)}`);
  child.stdin.write(JSON.stringify(msg) + "\n");
  if (!needReply) return Promise.resolve();
  return new Promise((resolve) => pending.set(msg.id, resolve));
}

// ---------- 握手：initialize -> initialized -> tools/list ----------
// ① 初始化：交换协议版本 + 能力
await send("initialize", {
  protocolVersion: "2024-11-05",
  capabilities: {},
  clientInfo: { name: "demo-client", version: "0.0.1" },
});

// ② 通知：客户端已就绪（无 id、无响应）
await send("notifications/initialized", {}, false);

// ③ 获取工具清单（真实 agent 会把它注入模型上下文）
const listResp = await send("tools/list", {});
const toolNames = listResp.result.tools.map((t) => t.name);
console.log(`\n=== 发现工具: ${toolNames.join(", ")} ===`);

// ---------- 调用工具 ----------
// ④ 调用无参工具
const t1 = await send("tools/call", {
  name: "get_time",
  arguments: {},
});
console.log(`\n=== get_time 结果: ${t1.result.content[0].text} ===`);

// ⑤ 调用带参工具
const t2 = await send("tools/call", {
  name: "echo",
  arguments: { message: "Hello MCP", prefix: "[INFO]" },
});
console.log(`\n=== echo 结果: ${t2.result.content[0].text} ===`);

// ⑥ 截图工具（image 返回）——真实调用 Windows PowerShell 截屏
console.log("\n=== 调用 take_screenshot（截取当前屏幕）===");
const s1 = await send("tools/call", { name: "take_screenshot", arguments: {} });
const img = s1.result.content[0];
console.log(
  `\n=== take_screenshot: type=${img.type}, mimeType=${img.mimeType}, base64长度=${img.data.length} ===`
);
await writeFile(join(PROJECT_DIR, "screenshot.png"), Buffer.from(img.data, "base64"));
console.log(`=== 已保存到 mcp-demo/screenshot.png ===`);

// ⑦ 协议错误演示 1：缺必填参数 message
// 注意：SDK 不校验 inputSchema 的 required，handler 显式校验后返回 isError: true
console.log("\n=== 调用 echo 但缺必填参数 message ==");
const e1 = await send("tools/call", { name: "echo", arguments: {} });
console.log(
  `\n=== echo 缺参 -> result.isError=${e1.result?.isError}, 内容=${e1.result?.content?.[0]?.text} ===`
);

// ⑧ 协议错误演示 2：调用不存在的工具（服务器 handler 抛错）
console.log("\n=== 调用不存在的工具 no_such_tool ==");
const e2 = await send("tools/call", { name: "no_such_tool", arguments: {} });
console.log(`\n=== 未知工具 -> 错误: code=${e2.error.code}, message=${e2.error.message} ===`);

// ---------- 生命周期：关闭 stdin，观察服务器退出 ----------
console.log("\n=== 关闭 stdin（模拟客户端退出）===");
child.stdin.end();
child.on("exit", (code) => {
  console.log(`\n=== 服务器进程已退出, code=${code}（管道关闭即生命结束）===`);
});
