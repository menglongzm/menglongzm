// ============================================================
// JS 基础 04：对象与数组
// 运行：node 04-objects-arrays.js
// ============================================================

// ---------- ① 对象（Object） ----------
console.log("① 对象基础");

const person = {
  name: "小明",
  age: 18,
  city: "北京",
  greet() {
    return `你好，我是${this.name}`;
  }
};

console.log(person.name);        // 点语法
console.log(person["age"]);      // 括号语法
console.log(person.greet());     // 调用方法

// 解构赋值
const { name, age } = person;
console.log(`解构: name=${name}, age=${age}`);

// 展开运算符（...）
const person2 = { ...person, city: "上海" };  // 复制并修改
console.log(person2);

// ---------- ② 数组（Array） ----------
console.log("\n② 数组基础");

const numbers = [1, 2, 3, 4, 5];
console.log(numbers[0]);         // 索引访问
console.log(numbers.length);     // 长度

// 常用方法
numbers.push(6);                 // 末尾添加
numbers.pop();                   // 末尾删除
numbers.unshift(0);              // 开头添加
numbers.shift();                 // 开头删除
console.log("修改后:", numbers);

// 查找
console.log("includes(3):", numbers.includes(3));
console.log("indexOf(3):", numbers.indexOf(3));

// 切片
console.log("slice(1,3):", numbers.slice(1, 3));  // [2, 3]

// ---------- ③ 对象数组（常见数据结构） ----------
console.log("\n③ 对象数组");

const users = [
  { id: 1, name: "小明", age: 18 },
  { id: 2, name: "小红", age: 20 },
  { id: 3, name: "小刚", age: 19 },
];

// 查找单个
const user = users.find(u => u.id === 2);
console.log("find:", user);

// 过滤
const adults = users.filter(u => u.age >= 19);
console.log("filter:", adults);

// 映射
const names = users.map(u => u.name);
console.log("map:", names);

// 排序
users.sort((a, b) => a.age - b.age);
console.log("sort:", users);

// ---------- ④ JSON（对象 ↔ 字符串） ----------
console.log("\n④ JSON");

const obj = { name: "小明", age: 18 };
const jsonStr = JSON.stringify(obj);
console.log("对象 → 字符串:", jsonStr);

const parsed = JSON.parse(jsonStr);
console.log("字符串 → 对象:", parsed);

// ---------- ⑤ 可选链（?.）和空值合并（??） ----------
console.log("\n⑤ 可选链与空值合并");

const data = { user: { name: "小明" } };
console.log(data.user?.name);     // "小明"
console.log(data.user?.age);      // undefined（不会报错）
console.log(data.user?.age ?? 18); // 18（空值合并，用默认值）

console.log("\n✅ 对象和数组是 JS 最常用的数据结构！");
